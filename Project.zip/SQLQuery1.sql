CREATE TABLE users (
    id INT IDENTITY(1,1) PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
	username VARCHAR(100),
	address VARCHAR(255),
	gsm_number VARCHAR(20) UNIQUE
);

CREATE TABLE TEST(
	id INT IDENTITY(1,1) PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
	username VARCHAR(100),
	address VARCHAR(255),
	gsm_number VARCHAR(20) UNIQUE
);
SELECT * FROM users

CREATE TABLE contacts (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name VARCHAR(100),
    surname VARCHAR(100),
    phone_number VARCHAR(20),
    email VARCHAR(255),
    address TEXT
);



CREATE TABLE user_contacts (
    user_id INT FOREIGN KEY REFERENCES users(id),
    contact_id INT FOREIGN KEY REFERENCES contacts(id),
    PRIMARY KEY(user_id, contact_id)
);


CREATE PROCEDURE prVerifyUnamePwd
	@username VARCHAR(255),
	@password VARCHAR(255),
	@role VARCHAR(50) OUTPUT
AS
BEGIN
	SELECT @role = role FROM users WHERE email = @username AND @password = password;
END;



CREATE PROCEDURE prRetrieveUserContacts
	@username VARCHAR(255)
AS
BEGIN
	
	SELECT c.*
	FROM users u
	JOIN user_contacts uc ON u.id = uc.user_id
	JOIN contacts c ON uc.contact_id = c.id
	WHERE u.email = @username

END



CREATE PROCEDURE prCreateUser
	@username VARCHAR(100),
	@name VARCHAR(100),
	@surname VARCHAR(100),
	@gsmNum VARCHAR(100),
	@email VARCHAR(100),
	@role VARCHAR(100),
	@address VARCHAR(100),
	@password VARCHAR(100)
AS
BEGIN
	INSERT INTO users(first_name, last_name, username, email, role, address, gsm_number, password)
	VALUES(@name, @surname, @username, @email, @role, @address, @gsmNum, @password)
END


CREATE PROCEDURE prCreateUser
	@username VARCHAR(100),
	@name VARCHAR(100),
	@surname VARCHAR(100),
	@gsmNum VARCHAR(100),
	@email VARCHAR(100),
	@role VARCHAR(100),
	@address VARCHAR(100),
	@password VARCHAR(100)
AS
BEGIN
	INSERT INTO users(first_name, last_name, username, email, role, address, gsm_number, password)
	VALUES(@name, @surname, @username, @email, @role, @address, @gsmNum, @password)
END

SELECT * FROM contacts

CREATE PROCEDURE prCreateContact
	@username VARCHAR(100),
	@name VARCHAR(100),
	@surname VARCHAR(100),
	@gsmNum VARCHAR(100),
	@email VARCHAR(100),
	@address VARCHAR(100),
	@userUserName VARCHAR(100)
AS
BEGIN
	INSERT INTO contacts (name, surname, phone_number, email, address, username)
	VALUES (@name, @surname, @gsmNum, @email, @address, @username)

	INSERT INTO user_contacts(user_id, contact_id)
	values((
	SELECT id FROM users
	WHERE username = @userUserName),
	(SELECT id from contacts 
	WHERE username = @username))

END

CREATE PROCEDURE prRemoveContact
	@username VARCHAR(100)
AS
BEGIN
	DELETE FROM contacts
	WHERE username = @username

END



CREATE PROCEDURE prRemoveUser
	@username VARCHAR(100)
AS
BEGIN
	DELETE FROM users
	WHERE username = @username
END



CREATE PROCEDURE prUpdateUser
	@username VARCHAR(100),
	@name VARCHAR(100),
	@surname VARCHAR(100),
	@gsmNum VARCHAR(100),
	@email VARCHAR(100),
	@address VARCHAR(100),
	@password VARCHAR(100),
	@role VARCHAR(100)
AS
BEGIN
	UPDATE users
	SET first_name = @name,
		last_name = @surname,
		gsm_number = @gsmNum,
		email = @email,
		username = @username, 
		address = @address,
		password = @password,
		role = @role
		WHERE gsm_number = @gsmNum
END



CREATE PROCEDURE prUpdateContact
	@username VARCHAR(100),
	@name VARCHAR(100),
	@surname VARCHAR(100),
	@gsmNum VARCHAR(100),
	@email VARCHAR(100),
	@address VARCHAR(100)
AS
BEGIN
	UPDATE contacts
	SET name = @name,
		surname = @surname,
		phone_number = @gsmNum,
		email = @email,
		address = @address,
		username = @username
		WHERE phone_number = @gsmNum
END


CREATE PROCEDURE prAddExistingContact
	@contactUsername VARCHAR(100),
	@username VARCHAR(100)
AS
BEGIN
	INSERT INTO user_contacts (user_id, contact_id)
	VALUES((SELECT id FROM users
	WHERE username = @username),
	(SELECT id FROM contacts
	WHERE username = @contactUsername))
END


CREATE TRIGGER trAutoGenerateUsername
ON users
AFTER INSERT
AS
BEGIN
	UPDATE users
	SET username = LOWER(REPLACE(CONCAT(users.first_name, users.last_name), ' ', ''))
	FROM users
	JOIN inserted ON users.id = inserted.id;
END

CREATE TRIGGER trAutoGenerateContactUsername
ON contacts
AFTER INSERT
AS 
BEGIN
	UPDATE contacts
	SET username = LOWER(REPLACE(CONCAT(contacts.name, contacts.surname), ' ', ''))
	FROM contacts
	JOIN inserted ON contacts.id = inserted.id
END
